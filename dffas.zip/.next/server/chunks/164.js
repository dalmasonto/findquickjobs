"use strict";
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ ColorSchemeToggle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__);



function ColorSchemeToggle() {
    const { colorScheme , toggleColorScheme  } = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineColorScheme)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
        position: "center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.ActionIcon, {
            onClick: ()=>toggleColorScheme(),
            size: "md",
            sx: (theme)=>({
                    backgroundColor: theme.colorScheme === "dark" ? theme.colors.dark[6] : theme.colors.gray[0],
                    color: theme.colorScheme === "dark" ? theme.colors.yellow[4] : theme.colors.blue[6]
                }),
            children: colorScheme === "dark" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconSun, {
                size: 20,
                stroke: 1.5
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconMoonStars, {
                size: 20,
                stroke: 1.5
            })
        })
    });
}


/***/ }),

/***/ 4164:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AppWrapper)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mantine/core"
var core_ = __webpack_require__(2247);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/common/CustomNavlink.tsx




const CustomNavlink = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: props?.navlink?.href,
        as: props?.navlink?.href,
        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
            p: "md",
            sx: (theme)=>({
                    border: "none",
                    // color: theme.colors.pink[6],
                    background: "transparent",
                    fontSize: "16px",
                    fontWeight: 400,
                    "&:hover": {
                        background: "transparent",
                        color: theme.colors.indigo[6]
                    }
                }),
            children: props?.navlink?.label
        })
    });
};
/* harmony default export */ const common_CustomNavlink = (CustomNavlink);

// EXTERNAL MODULE: ./configs/appConfigs.ts
var appConfigs = __webpack_require__(993);
// EXTERNAL MODULE: ./components/theme/ColorSchemeToggle.tsx
var ColorSchemeToggle = __webpack_require__(725);
;// CONCATENATED MODULE: ./layouts/AppWrapper.tsx






function AppWrapper(props) {
    const [opened, setOpened] = (0,external_react_.useState)(false);
    const theme = (0,core_.useMantineTheme)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.AppShell, {
        styles: {
            main: {
                background: theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.colors.gray[0]
            }
        },
        navbarOffsetBreakpoint: "sm",
        asideOffsetBreakpoint: "sm",
        // navbar={
        //   <MediaQuery largerThan="sm" styles={{ display: 'none' }}>
        //   <Navbar p="md" hiddenBreakpoint="sm" hidden={!opened} width={{ sm: 200, lg: 250 }}>
        //     <Text>Application navbar</Text>
        //   </Navbar>
        //   </MediaQuery>
        // }
        // aside={
        //   <MediaQuery smallerThan="sm" styles={{ display: 'none' }}>
        //     <Aside p="md" hiddenBreakpoint="sm" width={{ sm: 200, lg: 300 }}>
        //       <Text>Application sidebar</Text>
        //     </Aside>
        //   </MediaQuery>
        // }
        // footer={
        //   <Footer height={60} p="md">
        //     Application footer
        //   </Footer>
        // }
        header: /*#__PURE__*/ jsx_runtime_.jsx(core_.Header, {
            height: 60,
            sx: (theme)=>({
                    borderBottom: "none"
                }),
            children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Container, {
                size: "xl",
                className: "h-100",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Group, {
                    align: "center",
                    position: "apart",
                    className: "h-100",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(core_.Title, {
                            order: 4,
                            style: {
                                textTransform: "uppercase"
                            },
                            children: appConfigs/* APP_NAME */.iC
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(core_.Group, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(core_.MediaQuery, {
                                smallerThan: "md",
                                styles: {
                                    display: "none"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Group, {
                                    className: "h-100",
                                    children: appConfigs/* navlinks.filter */.M_.filter((l)=>l.in_nav).map((link, i)=>/*#__PURE__*/ jsx_runtime_.jsx(common_CustomNavlink, {
                                            navlink: link
                                        }, `_navlink_${i}`))
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-100",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Group, {
                                className: "h-100",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(core_.MediaQuery, {
                                        largerThan: "md",
                                        styles: {
                                            display: "none"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Burger, {
                                            opened: opened,
                                            onClick: ()=>setOpened((o)=>!o),
                                            size: "sm",
                                            color: theme.colors.gray[6]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ColorSchemeToggle/* ColorSchemeToggle */.e, {})
                                ]
                            })
                        })
                    ]
                })
            })
        }),
        padding: 0,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(core_.Drawer, {
                opened: opened,
                onClose: ()=>setOpened(false),
                title: "Register",
                padding: "xl",
                size: "lg",
                position: "left",
                children: "opened"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "min-height",
                children: props?.children
            })
        ]
    });
}


/***/ })

};
;