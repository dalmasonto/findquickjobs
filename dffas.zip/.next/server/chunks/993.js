"use strict";
exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DP": () => (/* binding */ APP_NAME_WITH_SEP),
/* harmony export */   "It": () => (/* binding */ APP_NAME_FULL),
/* harmony export */   "M_": () => (/* binding */ navlinks),
/* harmony export */   "UD": () => (/* binding */ SEPARATOR),
/* harmony export */   "iC": () => (/* binding */ APP_NAME),
/* harmony export */   "mX": () => (/* binding */ THEME_COOKIE_NAME)
/* harmony export */ });
const APP_NAME = "PAJ";
const APP_NAME_FULL = "Post a Job";
const SEPARATOR = " | ";
const APP_NAME_WITH_SEP = APP_NAME + SEPARATOR;
const THEME_COOKIE_NAME = "lsd-theme";
const navlinks = [
    {
        href: "/",
        label: "Home",
        in_nav: true,
        in_footer: true
    },
    {
        href: "/properties",
        label: "Properties",
        in_nav: true,
        in_footer: true
    },
    {
        href: "/listings",
        label: "Listings",
        in_nav: true,
        in_footer: true
    },
    {
        href: "/search",
        label: "Search",
        in_nav: true,
        in_footer: true
    },
    {
        href: "/pricing",
        label: "Pricing",
        in_nav: false,
        in_footer: false
    },
    {
        href: "/about",
        label: "About",
        in_nav: false,
        in_footer: true
    },
    {
        href: "/contact-us",
        label: "Contact Us",
        in_nav: true,
        in_footer: true
    },
    {
        href: "/auth/login",
        label: "Login",
        in_nav: true,
        in_footer: false
    },
    {
        href: "/auth/signup",
        label: "Sign Up",
        in_nav: true,
        in_footer: false
    }
];


/***/ })

};
;