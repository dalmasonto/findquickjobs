(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "cookies-next"
const external_cookies_next_namespaceObject = require("cookies-next");
// EXTERNAL MODULE: external "@mantine/core"
var core_ = __webpack_require__(2247);
;// CONCATENATED MODULE: external "@mantine/modals"
const modals_namespaceObject = require("@mantine/modals");
;// CONCATENATED MODULE: external "@mantine/notifications"
const notifications_namespaceObject = require("@mantine/notifications");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./configs/appConfigs.ts
var appConfigs = __webpack_require__(993);
;// CONCATENATED MODULE: ./layouts/MantineWrapper.tsx







function MantineWrapper(props) {
    const [colorScheme, setColorScheme] = (0,external_react_.useState)(props.colorScheme);
    const toggleColorScheme = (value)=>{
        const nextColorScheme = value || (colorScheme === "dark" ? "light" : "dark");
        setColorScheme(nextColorScheme);
        (0,external_cookies_next_namespaceObject.setCookie)(appConfigs/* THEME_COOKIE_NAME */.mX, nextColorScheme, {
            maxAge: 60 * 60 * 24 * 30
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.ColorSchemeProvider, {
            colorScheme: colorScheme,
            toggleColorScheme: toggleColorScheme,
            children: /*#__PURE__*/ jsx_runtime_.jsx(core_.MantineProvider, {
                theme: {
                    colorScheme
                },
                withGlobalStyles: true,
                withNormalizeCSS: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx(modals_namespaceObject.ModalsProvider, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(notifications_namespaceObject.NotificationsProvider, {
                        children: props?.children
                    })
                })
            })
        })
    });
}

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
;// CONCATENATED MODULE: ./pages/_app.tsx






function App(props) {
    const { Component , pageProps  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: `${appConfigs/* APP_NAME_WITH_SEP */.DP} Welcome`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "minimum-scale=1, initial-scale=1, width=device-width"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: "/favicon.svg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: "/favicon.svg"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MantineWrapper, {
                colorScheme: props.colorScheme,
                children: Component.PageLayout ? /*#__PURE__*/ jsx_runtime_.jsx(Component.PageLayout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                }) : /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}
App.getInitialProps = ({ ctx  })=>({
        colorScheme: (0,external_cookies_next_namespaceObject.getCookie)(appConfigs/* THEME_COOKIE_NAME */.mX, ctx) || "light"
    });


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 2247:
/***/ ((module) => {

"use strict";
module.exports = require("@mantine/core");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [993], () => (__webpack_exec__(2350)));
module.exports = __webpack_exports__;

})();