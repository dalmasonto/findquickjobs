import React from 'react'
import AppWrapper from '../layouts/AppWrapper'

const Properties = () => {
  return (
    <div>properties</div>
  )
}

Properties.PageLayout = AppWrapper

export default Properties